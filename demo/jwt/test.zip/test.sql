-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 12, 2018 at 01:58 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.0.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `saved_locations`
--

CREATE TABLE `saved_locations` (
  `id` int(11) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `zip` varchar(15) NOT NULL,
  `country` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `latitude` varchar(25) NOT NULL,
  `longitude` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saved_locations`
--

INSERT INTO `saved_locations` (`id`, `city`, `state`, `zip`, `country`, `address`, `latitude`, `longitude`) VALUES
(1, 'Bengaluru', 'KA', '560023', 'IN', ', ', '12.9781289', '77.56956779999996'),
(2, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(3, 'Bengaluru', 'KA', '560013', 'IN', ', ', '13.0467724', '77.54744329999994'),
(4, 'Bengaluru', 'KA', '560097', 'IN', ', ', '13.066031', '77.57343990000004'),
(5, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(6, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(7, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(8, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(9, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(10, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(11, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(12, 'Bengaluru', 'KA', '560068', 'IN', ', ', '12.9171333', '77.62278289999995'),
(13, 'Kolkata', 'WB', '700014', 'IN', ', ', '22.5659744', '88.36566730000004'),
(14, 'Kolkata', 'WB', '700014', 'IN', ', ', '22.5659744', '88.36566730000004'),
(15, 'Bengaluru', 'KA', '560006', 'IN', ', ', '13.0034007', '77.59311809999997'),
(16, 'Washington', 'DC', '20001', 'US', ', ', '38.9031594', '-77.02124830000002'),
(17, 'KCMO', 'MO', '64153', 'US', ', ', '39.2991181', '-94.71077860000003');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fname` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`) VALUES
(1, 'Super Admin', 'A', 'skp.pvt@gmail.com', '$2y$10$fIiRasuZkAdybX9aQGlSXeYexAzcJQiWNsPOzf/MvVgpkBeMDKU1O'),
(5, 'puspa', 'lata', 'march.skp@gmail.com', '$2y$10$5ZPC.VFW493.Nf702P6AM.r2F9nooWjo60ykvrqj87tRFjDQicUx2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `saved_locations`
--
ALTER TABLE `saved_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `saved_locations`
--
ALTER TABLE `saved_locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
